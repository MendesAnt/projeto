<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}
require_once __DIR__ . '/src/conexao-bd.php';

$id = (int) ($_GET['id'] ?? 0);

/* busca os dados atuais */
$stmt = $pdo->prepare("SELECT * FROM tbNoticia WHERE id_noticia = ?");
$stmt->execute([$id]);
$not = $stmt->fetch();
if (!$not) {
    exit('Notícia não encontrada.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome     = $_POST['nome_noticia'];
    $conteudo = $_POST['conteudo_noticia'];
    $fonte    = $_POST['fonte_noticia'];
    $imagem   = $not['imagem']; // mantém atual

    /* novo upload */
    if (!empty($_FILES['imagem']['name'])) {
        $ext = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
        $nomeImg = uniqid() . '.' . $ext;
        $caminho = 'img/' . $nomeImg;

        if (!is_dir('img')) mkdir('img', 0777, true);
        if (move_uploaded_file($_FILES['imagem']['tmp_name'], $caminho)) {
            /* apaga antiga, se existir */
            if ($imagem && file_exists($imagem)) unlink($imagem);
            $imagem = $caminho;
        }
    }

    $sql = "UPDATE tbNoticia
            SET nome_noticia = ?, conteudo_noticia = ?, fonte_noticia = ?, imagem = ?
            WHERE id_noticia = ?";
    $pdo->prepare($sql)->execute([$nome, $conteudo, $fonte, $imagem, $id]);

    header('Location: ler-noticia.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>FootNews - Editar Notícia</title>
    <link rel="stylesheet" href="css/style-admin.css">
    <link rel="stylesheet" href="css/editar-noticia.css">
</head>
<body>
    <header>FootNews</header>

    <main class="cadastro-container">
        <h2>EDITAR NOTÍCIA</h2>

        <form method="post" enctype="multipart/form-data">
            <label>Título
                <input type="text" name="nome_noticia" value="<?= htmlspecialchars($not['nome_noticia']) ?>" required>
            </label>

            <label>Fonte
                <input type="text" name="fonte_noticia" value="<?= htmlspecialchars($not['fonte_noticia']) ?>" required>
            </label>

            <label>Conteúdo
                <textarea name="conteudo_noticia" rows="6" required><?= htmlspecialchars($not['conteudo_noticia']) ?></textarea>
            </label>

            <label>Imagem (deixe em branco para manter atual)
                <input type="file" name="imagem" accept="image/*">
            </label>

            <?php if ($not['imagem']): ?>
                <p>Imagem atual:</p>
                <img src="<?= htmlspecialchars($not['imagem']) ?>" style="max-width:200px;">
            <?php endif; ?>

            <button type="submit">Salvar</button>
            <a href="admin.php">Cancelar</a>
        </form>
    </main>
</body>
</html>