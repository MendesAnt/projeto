<?php
session_start();
require_once 'src/conexao-bd.php'; 

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha']   ?? '';

if ($email === '' || $senha === '') {
    header('Location: login.php?erro=campos');
    exit;
}

if ($email === 'admin@exemplo.com' && $senha === '1234') {
    session_regenerate_id(true);
    $_SESSION['usuario'] = 'admin'; 
    header('Location: admin.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM tbUsuario WHERE email_usuario = ?');
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user && $user['senha_usuario'] === $senha) {
    session_regenerate_id(true);
    $_SESSION['usuario'] = $user['nomeUsuario_usuario'];
    $_SESSION['is_admin'] = false;
    header('Location: index.php');  
    exit;
}

header('Location: login.php?erro=dados incorretos!');
exit;
?>