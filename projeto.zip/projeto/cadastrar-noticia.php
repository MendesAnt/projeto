<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

require_once 'src/conexao-bd.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome     = $_POST['nome_noticia']    ?? '';
    $conteudo = $_POST['conteudo_noticia'] ?? '';
    $fonte    = $_POST['fonte_noticia']   ?? '';
    $imagem   = null;

    if (!empty($_FILES['imagem']['name'])) {
        $ext  = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
        $nomeImg = uniqid() . '.' . $ext;
        $caminho = 'img/' . $nomeImg;

        if (!is_dir('img')) mkdir('img', 0777, true);

        if (move_uploaded_file($_FILES['imagem']['tmp_name'], $caminho)) {
            $imagem = $caminho;
        } else {
            echo "<script>alert('Erro ao enviar imagem.');history.back();</script>";
            exit;
        }
    }

    $sql = "INSERT INTO tbNoticia (nome_noticia, conteudo_noticia, fonte_noticia, imagem)
            VALUES (:nome, :conteudo, :fonte, :imagem)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':nome'     => $nome,
        ':conteudo' => $conteudo,
        ':fonte'    => $fonte,
        ':imagem'   => $imagem
    ]);

    header('Location: admin.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>FootNews - Cadastrar Notícia</title>
    <link rel="stylesheet" href="css/style-admin.css">
    <link rel="stylesheet" href="css/cadastrar-noticia.css">
</head>
<body>
    <header>FootNews</header>

    <main class="cadastro-container">
        <h2>CADASTRAR NOTÍCIA</h2>

        <form method="post" enctype="multipart/form-data">
            <label>Título
                <input type="text" name="nome_noticia" required>
            </label>

            <label>Fonte (texto)
                <input type="text" name="fonte_noticia" required>
            </label>

            <label>Conteúdo
                <textarea name="conteudo_noticia" rows="6" required></textarea>
            </label>

            <label>Imagem
                <input type="file" name="imagem" accept="image/*">
            </label>

            <button type="submit">Salvar</button>
            <a href="admin.php">Cancelar</a>
        </form>
    </main>
</body>
</html>