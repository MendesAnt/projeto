<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}
require_once __DIR__ . '/src/conexao-bd.php';

$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT imagem FROM tbNoticia WHERE id_noticia = ?");
$stmt->execute([$id]);
$img = $stmt->fetchColumn();
if ($img && file_exists($img)) unlink($img);

$pdo->prepare("DELETE FROM tbNoticia WHERE id_noticia = ?")->execute([$id]);

header('Location: admin.php');
exit;
?>