<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/src/conexao-bd.php'; 

try {
    $stmt = $pdo->query("
        SELECT id_noticia, 
               nome_noticia, 
               fonte_noticia, 
               conteudo_noticia, 
               imagem
        FROM tbNoticia
        ORDER BY id_noticia ASC
    ");
    $noticias = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    exit('Erro ao buscar notícias: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>FootNews - Listar Notícias</title>
    <link rel="stylesheet" href="css/style-admin.css"/>
    <link rel="stylesheet" href="css/ler-noticia.css"/>
</head>
<body>
    <header>FootNews</header>

    <main class="lista-noticias">
        <div class="admin-container">
        <h1>ADMINISTRAÇÃO</h1><br><br><br>

        <a href="cadastrar-noticia.html" class="botao">Cadastrar notícia</a><br><br>
        <h2>NOTÍCIAS CADASTRADAS</h2>

        <?php if (!$noticias): ?>
            <p>Nenhuma notícia cadastrada.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Imagem</th>
                        <th>Título</th>
                        <th>Fonte</th>
                        <th>Conteúdo</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($noticias as $n): ?>
                        <tr>
                            <td><?= $n['id_noticia'] ?></td>
                            <td>
                                <img src="<?= htmlspecialchars($n['imagem']) ?>" alt="Imagem" style="max-width:120px;">
                            </td>
                            <td><?= htmlspecialchars($n['nome_noticia']) ?></td>
                            <td><?= htmlspecialchars($n['fonte_noticia']) ?></td>
                            <td><?= nl2br(htmlspecialchars($n['conteudo_noticia'])) ?></td>
                            <td>
                                <a href="alterar-noticia.php?id=<?= $n['id_noticia'] ?>" class = "icon-btn"><img src="img/icon-lapis.png" alt="editar"></a>
                                <a href="excluir-noticia.php?id=<?= $n['id_noticia'] ?>" onclick="return confirm('Excluir?')" class = "icon-btn"><img src="img/icon-lixo.png" alt="excluir"></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <p class="voltar">
            <a href="login.php">← Voltar ao painel</a>
        </p>
    </main>
</body>
</html>