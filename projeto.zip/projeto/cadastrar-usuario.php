<?php
require_once 'src/conexao-bd.php';

$real  = $_POST['nomeReal_usuario'];
$user  = $_POST['nomeUsuario_usuario'];
$email = $_POST['email_usuario'];
$senha = $_POST['senha_usuario'];

$sql = "INSERT INTO tbUsuario (nomeReal_usuario, nomeUsuario_usuario, email_usuario, senha_usuario)
        VALUES (?, ?, ?, ?)";
$stmt = $pdo->prepare($sql);
$stmt->execute([$real, $user, $email, $senha]);

header('Location: login.php?cad=ok');
exit;
?>